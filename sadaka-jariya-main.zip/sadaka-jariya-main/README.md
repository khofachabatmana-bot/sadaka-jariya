# sadaka-jariya
